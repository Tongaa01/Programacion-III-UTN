import { handleGetProductLocalStorage } from "../persistence/localStorage";
import { renderCategories } from "../services/categories";
import { setProductoActivo } from "../../main";
import { openModal, closeModal } from "./modal";


export const handleGetProductsToStore = () => {
    const products = handleGetProductLocalStorage();
    handleRenderList(products);
}

export const handleRenderList = (productsIn) => {
    const knives = productsIn.filter((el) => el.categoria === "Cuchillos")
    const handguns = productsIn.filter((el) => el.categoria === "Armas de mano")
    const semiautomatics = productsIn.filter((el) => el.categoria === "Semiautomáticas")
    const automatics = productsIn.filter((el) => el.categoria === "Automáticas")
    const throwables = productsIn.filter((el) => el.categoria === "Arrojadizas")

    console.log(productsIn);

    const renderProductGroup = (productos, title) => {
        if (productos.length > 0) {
            const productosHTML = productos.map((producto, index) => {
                return `
                    <div class="containerTargetItem" id="product-${producto.categoria}-${index}">
                        <div>
                            <img src="${producto.imagen}">
                            <div>
                                <h2>${producto.nombre}</h2>
                            </div>
                            <div class="targetProp">
                                <p><b>Precio:</b> $${producto.precio}</p>
                            </div>
                        </div>
                    </div>
                `
            });
            return `
            <section class="sectionStore">
                <div class="containerTitleSection">
                    <h3>${title}</h3>
                </div>
                <div class="containerProductStore">${productosHTML.join("")}</div>
            </section>
            `
        } else {
            return ""
        }
    };

    const appContainer = document.getElementById("storeContainer");
    appContainer.innerHTML = `
    ${renderProductGroup(knives,"Cuchillos")}
    ${renderProductGroup(handguns,"Armas de mano")}
    ${renderProductGroup(semiautomatics,"Semiautomáticas")}
    ${renderProductGroup(automatics,"Automáticas")}
    ${renderProductGroup(throwables,"Arrojadizas")}
    `

    const addEvents = (productsIn)=>{
        productsIn.forEach((element, index) => {
            const productContainer = document.getElementById(
                `product-${element.categoria}-${index}`)
                productContainer.addEventListener("click", ()=>{
                    setProductoActivo(element);
                    openModal();
                })
        });
    }

    addEvents(knives)
    addEvents(handguns)
    addEvents(semiautomatics)
    addEvents(automatics)
    addEvents(throwables)
};