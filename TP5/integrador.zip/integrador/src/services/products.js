import { handleGetProductLocalStorage, setInLocalStorage } from "../persistence/localStorage";
import { handleGetProductsToStore, handleRenderList } from "../views/store";
import { closeModal } from "../views/modal";
import { productoActivo } from "../../main";
import Swal from "sweetalert2";




export const handleSaveOrModifyElements = () => {
    const nombre = document.getElementById("name").value,
        imagen = document.getElementById("img").value,
        precio = document.getElementById("price").value,
        categoria = document.getElementById("category").value;

    let object = null;
    if (productoActivo) {
        object = {
            ...productoActivo, 
            nombre,
            imagen,
            precio,
            categoria
        }
    } else {
        object = {
            id: new Date().toISOString(),
            nombre,
            imagen,
            precio,
            categoria
        }
    }

    Swal.fire({
        position: "top-end",
        icon: "success",
        title: "Producto guardado",
        showConfirmButton: false,
        timer: 1500
      });

    setInLocalStorage(object);
    handleGetProductsToStore();
    closeModal();
}

export const handleDeleteProduct = ()=>{

    Swal.fire({
        title: "¿Seguro?",
        text: "Esta acción es permanente",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Eliminar"
    }).then((result) => {
        if (result.isConfirmed) {
            const products = handleGetProductLocalStorage();
            const result = products.filter((el)=> el.id !== productoActivo.id);

            localStorage.setItem("products", JSON.stringify(result));

            const newProducts = handleGetProductLocalStorage();
            handleRenderList(newProducts);
            closeModal();
        } else {
            closeModal();
        }
      });

    
}