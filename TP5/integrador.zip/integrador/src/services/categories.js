import { handleGetProductLocalStorage } from "../persistence/localStorage";
import { handleRenderList } from "../views/store";
import { categoriaActiva } from "../../main";


export const handleFilterProductsByCategory = (categoryIn) => {
        const products = handleGetProductLocalStorage();

        switch (categoryIn) {
            case "All":
            case categoriaActiva:
                handleRenderList(products);
                break;
            case "Cuchillos":
            case "Armas de mano":
            case "Semiautomáticas":
            case "Automáticas":
            case "Arrojadizas":
                const result = products.filter((el)=>el.categoria === categoryIn)
                handleRenderList(result);
            default:
                break;
            case "HighPrice":
                const precioMayor = products.sort((a, b) => b.precio - a.precio);
                handleRenderList(precioMayor);
                break;
            case "LowPrice":
                const precioMenor = products.sort((a, b) => a.precio - b.precio);
                handleRenderList(precioMenor);
                break;
                
        }
}


export const renderCategories = ()=>{
    const ulList = document.getElementById("listFilter");
    ulList.innerHTML = `
    <li id="All">Limpiar filtros</li>
    <li id="HighPrice">Mayor precio</li>
    <li id="LowPrice">Menor precio</li>
    <li id="Cuchillos">Cuchillos</li>
    <li id="Armas de mano">Armas de mano</li>
    <li id="Semiautomáticas">Semiautomáticas</li>
    <li id="Automáticas">Automáticas</li>
    <li id="Arrojadizas">Arrojadizas</li>
    `
    const liElement = ulList.querySelectorAll("li");
    liElement.forEach((liElement)=>{
        liElement.addEventListener("click",()=>{
            console.log("click en", liElement.id);
            handleClick(liElement)
        })
    })

    const handleClick = (elemento)=>{
        handleFilterProductsByCategory(elemento.id)
        liElement.forEach((element)=>{
            if(element.classList.contains("liActive")){
                element.classList.remove("liActive")
            } else {
                if (elemento === element) {
                    element.classList.add("liActive")
                }
            }
        })
    }
}