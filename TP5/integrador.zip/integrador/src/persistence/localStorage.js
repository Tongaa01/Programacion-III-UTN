export const handleGetProductLocalStorage = () => {
    const products = JSON.parse(localStorage.getItem("products"))
    console.log(products);
    if (products) {
        return products;
    } else {
        return [];
    }
};

export const setInLocalStorage = (productIn) => {
    let productsInLocal = handleGetProductLocalStorage();
    const existingIndex = productsInLocal.findIndex((productsInLocal) => {
        return productsInLocal.id === productIn.id;
    })

    if (existingIndex !== -1) {
        productsInLocal[existingIndex] = productIn;
    } else {
        productsInLocal.push(productIn);
    }
    localStorage.setItem("products", JSON.stringify(productsInLocal))
}


// aqui esta un inicializador con todos los productos para que usted ya tenga precargados
// se encuentra comentado por defecto asi no se me reescribe nada por las dudas,
// pero la probé y anda

/*const inicializarProductos = () => {
    const productos = [
        {
            "id": "2024-09-20T01:07:53.037Z",
            "nombre": "Karambit Dorado",
            "imagen": "https://acdn.mitiendanube.com/stores/001/033/846/products/609b30fd-de2d-4073-985e-565ac832d7d11-7523f94eee992d4f6916788448781284-640-0.jpeg",
            "precio": "30000",
            "categoria": "Cuchillos"
        },
        {
            "id": "2024-09-20T01:08:16.616Z",
            "nombre": "Karambit verde",
            "imagen": "https://acdn.mitiendanube.com/stores/987/259/products/1-con-logo-nuevo41-b5070269d1b76abe3e16866027467792-640-0.jpg",
            "precio": "25000",
            "categoria": "Cuchillos"
        },
        {
            "id": "2024-09-20T01:09:53.199Z",
            "nombre": "Mariposa roja",
            "imagen": "https://knify.gg/medias/2023/11/real-cs-butterfly-knife-slaughter-irl-2000x2000.webp",
            "precio": "28000",
            "categoria": "Cuchillos"
        },
        {
            "id": "2024-09-20T01:10:27.811Z",
            "nombre": "Colt 1911",
            "imagen": "https://www.reborn.com.ar/wp-content/uploads/sites/2/2019/09/180512.png",
            "precio": "160000",
            "categoria": "Armas de mano"
        },
        {
            "id": "2024-09-20T01:10:59.743Z",
            "nombre": "Glock 19 5ta Gen",
            "imagen": "https://mosky.com.ar/wp-content/uploads/2023/06/GLOCK19GEN501.png",
            "precio": "190000",
            "categoria": "Armas de mano"
        },
        {
            "id": "2024-09-20T01:11:32.686Z",
            "nombre": "Desert Eagle .50 AE",
            "imagen": "https://cdn11.bigcommerce.com/s-kp97pt369w/images/stencil/1280x1280/products/3558/10102/SVimg-DE50ASIMB__21050.1621622372.jpg?c=2",
            "precio": "280000",
            "categoria": "Armas de mano"
        },
        {
            "id": "2024-09-20T01:13:24.097Z",
            "nombre": "Granada Fragmentaria",
            "imagen": "https://static.wikia.nocookie.net/miscreated/images/9/98/GrenadePickup_2048.png",
            "precio": "70000",
            "categoria": "Arrojadizas"
        },
        {
            "id": "2024-09-20T01:14:50.537Z",
            "nombre": "Set Cuchillos Arrojadizos",
            "imagen": "https://www.militarysurplus.eu/eng_pl_THROWING-KNIVES-SET-SPYDERTHROWERS-Spyderco-R-SMALL-44900_1.jpg",
            "precio": "100000",
            "categoria": "Arrojadizas"
        },
        {
            "id": "2024-09-20T01:15:36.164Z",
            "nombre": "AR-15",
            "imagen": "https://resizer.glanacion.com/resizer/v2/rifle-semiautomatico-ar-MV5G5WPJUFBFNIBLYPIQU7ENTQ.jpg?auth=d296ef44c4b5e80999e02efc341e1488b974f32c078f203c84660093168db962&width=420&height=279&quality=70&smart=true",
            "precio": "550000",
            "categoria": "Semiautomáticas"
        },
        {
            "id": "2024-09-20T01:16:03.602Z",
            "nombre": "Ruger SFAR",
            "imagen": "https://content.osgnetworks.tv/photopacks/ruger-small-frame-autoloading-rifle-sfar-a-308-win-in-a-223-package_471351/471369_ruger-small-frame-autoloading-rifle-sfar-full-view-hero_hero_1200x800.jpg",
            "precio": "480000",
            "categoria": "Semiautomáticas"
        },
        {
            "id": "2024-09-20T01:16:54.537Z",
            "nombre": "M4 Commando",
            "imagen": "https://machinegunamericaorlando.com/wp-content/uploads/2015/09/M4-Commando-640x450.png",
            "precio": "600000",
            "categoria": "Semiautomáticas"
        },
        {
            "id": "2024-09-20T01:18:14.917Z",
            "nombre": "Saiga-MK",
            "imagen": "https://roe.ru/upload/resize_cache/iblock/dc6/1920_700_1e3cd68611aa859771f9d287689e58ce0/dc6e608d81c4af7c3bb88efb1dd31d58.jpg",
            "precio": "780000",
            "categoria": "Automáticas"
        },
        {
            "id": "2024-09-20T01:19:18.047Z",
            "nombre": "KP-9",
            "imagen": "https://cdn11.bigcommerce.com/s-iv9a8pp5ge/images/stencil/1280x1280/products/299/1556/IMG_3347__67001.1660421498.JPG?c=1",
            "precio": "700000",
            "categoria": "Automáticas"
        },
        {
            "id": "2024-09-20T01:20:40.030Z",
            "nombre": "HK-G3 SG",
            "imagen": "https://ctfirearmsauction.com/content/uploads/2022/05/hk-g3-sg-1-308-transferable-machine-gun-180_1-scaled.jpg",
            "precio": "770000",
            "categoria": "Automáticas"
        }
    ];

    productos.forEach(producto => {
        setInLocalStorage(producto);
    });
};

inicializarProductos();*/