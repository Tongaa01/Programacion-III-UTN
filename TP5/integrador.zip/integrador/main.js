import { handleGetProductsToStore } from "./src/views/store";
import { renderCategories } from "./src/services/categories";
import { handleGetProductLocalStorage, setInLocalStorage } from "./src/persistence/localStorage";
import { closeModal, openModal } from "./src/views/modal";
import { handleSearchProductByName } from "./src/services/searchBar";
import { handleSaveOrModifyElements } from "./src/services/products";

export let categoriaActiva = null;
export const setCategoriaActiva = (categoriaIn) => {
    categoriaActiva = categoriaIn;
}

export let productoActivo = null;
export const setProductoActivo = (productoIn) => {
    productoActivo = productoIn;
}

handleGetProductsToStore();
renderCategories();

const buttonAdd = document.getElementById("buttonAddElement");
buttonAdd.addEventListener("click", () => {
    openModal();
})

const cancelButton = document.getElementById("cancelButton");
cancelButton.addEventListener("click", () => {
    closeModal();
})

const acceptButton = document.getElementById("acceptButton")
acceptButton.addEventListener("click", () => {
    handleSaveOrModifyElements();
})

const buttonSearch = document.getElementById("searchButton");
buttonSearch.addEventListener("click", ()=>{
    handleSearchProductByName();
})
